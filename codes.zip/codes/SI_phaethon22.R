rm(list=ls()) #clean dataset
#graphics.off()
#setwd("C:/Users/julia/Desktop/Workshop TABASCO/Entrada")

########################################################
###############                         ################       
###############        SIBER            ################
###############                         ################
########################################################

###### 2.1 General metrics ####

library(FSA)
data.iso <- read.csv2('data/PHAET/isotopos/P_aethereus_SI_SIBER.csv')
attach(data.iso)
View(data.iso)
data.iso <- data.iso[1:97,]
data.iso <- data.iso[-37,]
data.iso <- data.iso[-which(data.iso$community=="2011"),]
data.iso$community <- 'todo'
data.iso$group[which(data.iso$group == 'Femea')] = 'Female'
data.iso$group[which(data.iso$group == 'Macho')] = 'Male'

data.iso$iso1 <- as.numeric(data.iso$iso1)
data.iso$iso2 <- as.numeric(data.iso$iso2)

t_c <- wilcox.test(iso1~group,data=data.iso)
t_n <- wilcox.test(iso2~group,data=data.iso)

data2 <- data.iso %>% 
  dplyr::select(iso1,iso2,group) %>% 
  gather(isotopo,valor,-group)

metricas <- data2 %>% 
  group_by(group,isotopo) %>% 
  summarise(mean = mean(valor), sd = sd(valor))




`###### SIBER ####

library(ggplot2)
library(hrbrthemes)
library(SIBER)
library(ellipse)
library(dplyr)

class(data.iso$iso1) <- 'numeric'
class(data.iso$iso2) <- 'numeric'

siber.phaet <- createSiberObject(data.iso)

C_met <-Summarize(iso1 ~ group+community,
                  data = data.iso, digits=2)
C_met

N_met <-Summarize(iso2 ~ group+community,
                  data = data.iso, digits=2)
N_met


community.hulls.args <- list(col = 2, lty = 1, lwd = 1)
group.ellipses.args  <- list(n = 100, p.interval = 0.95, lty = 1, lwd = 2)
group.hull.args      <- list(lty = 2, col = "grey20")

group.ML <- groupMetricsML(siber.phaet)
print(group.ML)


# options for running jags
parms <- list()
parms$n.iter <- 2 * 10^4   # number of iterations to run the model for
parms$n.burnin <- 1 * 10^3 # discard the first set of values
parms$n.thin <- 10     # thin the posterior by this many
parms$n.chains <- 2        # run this many chains

# define the priors
priors <- list()
priors$R <- 1 * diag(2)
priors$k <- 2
priors$tau.mu <- 1.0E-3

ellipses.posterior <- siberMVN(siber.phaet, parms, priors)

# calculate the SEA.B for each colony.
SEA.B <- siberEllipses(ellipses.posterior)

siberDensityPlot(SEA.B, xticklabels = colnames(group.ML), 
                 xlab = c("Community | Group"),
                 ylab = expression("Standard Ellipse Area " ('\u2030' ^2) ),
                 bty = "L",
                 las = 1,
                 main = "SIBER ellipses on each group")

#----create-ellipse-df-
# how many of the posterior draws do you want 
n.posts <- 1

# how big an ellipse you want to draw
p.ell <- 0.95

# a list to store the results
all_ellipses <- list()

# loop over groups
for (i in 1:length(ellipses.posterior)){
  
  # a dummy variable to build in the loop
  ell <- NULL
  post.id <- NULL
  
  for ( j in 1:n.posts){
    
    # covariance matrix
    Sigma  <- matrix(ellipses.posterior[[i]][j,1:4], 2, 2)
    
    # mean
    mu     <- ellipses.posterior[[i]][j,5:6]
    
    # ellipse points
    out <- ellipse::ellipse(Sigma, centre = mu , level = p.ell)
    ell <- rbind(ell, out)
    post.id <- c(post.id, rep(j, nrow(out)))
  }
  
  ell <- as.data.frame(ell)
  ell$rep <- post.id
  all_ellipses[[i]] <- ell
}

ellipse_df <- bind_rows(all_ellipses, .id = "id")

# now we need the group and community names
# extract them from the ellipses.posterior list
group_comm_names <- names(ellipses.posterior)[as.numeric(ellipse_df$id)]

# split them and conver to a matrix, NB byrow = T
split_group_comm <- matrix(unlist(strsplit(group_comm_names, "[.]")),
                           nrow(ellipse_df), 2, byrow = TRUE)

ellipse_df$community <- split_group_comm[,1]
ellipse_df$group     <- split_group_comm[,2]

ellipse_df <- dplyr::rename(ellipse_df, iso1 = x, iso2 = y)

## plot-data-
first.plot <- ggplot(data.iso, aes(x = as.numeric(iso1),
                                   y = as.numeric(iso2), color=group)) + 
  geom_point() +
  theme_ipsum() + ylab(expression(paste(delta^{15}, "N (\u2030)"))) +
  xlab(expression(paste(delta^{13}, "C (\u2030)")))+ 
  theme(text = element_text(size=15)) +
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0), 
                                    size= 15, colour="black", face="bold")) +
  theme(axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0),
                                    size= 15, colour="black", face="bold")) +
  theme_bw()

ellipse.plot <- first.plot + 
  stat_ellipse(aes(group = interaction(group, community), 
                   fill = group, 
                   color = group), 
               alpha = 0.5, 
               level = p.ell,
               type = "norm",
               geom = "polygon")+
  scale_fill_manual(values = c("coral2","aquamarine4"))+
  scale_color_manual(values = c("coral2","aquamarine4"))+
  theme(legend.text = element_text(colour="black", size=8),
        axis.text = element_text(size = 7),
        axis.title = element_text(size = 8),
        legend.box.background = element_rect(fill = "transparent", colour = NA),
        legend.background = element_rect(fill = "transparent", colour = NA),
        legend.key = element_rect(fill = "transparent", colour = "transparent"),
        legend.position = c(.88,.92)) + 
    theme(legend.title = element_blank())
ggsave('figures/PHAET/sexes_niche.png', ellipse.plot, width = 10, 
       height = 10, units = 'cm')
ggsave('figures/PHAET/sexes_niche.tiff', ellipse.plot, width = 10, 
       height = 10, units = 'cm')




tiff("figures/PHAET/siber_phaethon.tiff", height=160, width=170, 
     units='mm', compression="lzw+p", res=600)
ellipse.plot
dev.off()
png("figures/PHAET/siber_phaethon.png", height=160, width=170, 
     units='mm',res=600)
ellipse.plot
dev.off()

# to calculate the overlap area between the ellipses
anos <- 2018:2021
ellipse1 <- paste0(anos,'.Macho')
ellipse2 <- paste0(anos,'.Femea')

# the overlap betweeen the corresponding 95% prediction ellipses is given by: 
table_overlap50 <- NULL
table_overlap75 <- NULL
table_overlap95 <- NULL

for(i in 1:length(anos)){
  ellipse50.overlap <- maxLikOverlap(ellipse1[i], ellipse2[i], siber.phaet,
                                     p.interval = 0.5, n = 100)
  t1 <- data.frame(ano = anos[i], 
                   overlap = as.numeric(ellipse50.overlap[3])*100,
                   porcent = 50)
  table_overlap50 = rbind(t1,table_overlap50)
  ellipse75.overlap <- maxLikOverlap(ellipse1[i], ellipse2[i], siber.phaet,
                                     p.interval = 0.75, n = 100)
  t2 <- data.frame(ano = anos[i], 
                   overlap = as.numeric(ellipse75.overlap[3])*100,
                   porcent = 75)
  table_overlap75 = rbind(t2,table_overlap75)  
  ellipse95.overlap <- maxLikOverlap(ellipse1[i], ellipse2[i], siber.phaet,
                                     p.interval = 0.95, n = 100)
  t3 <- data.frame(ano = anos[i], 
                   overlap = as.numeric(ellipse95.overlap[3])*100,
                   porcent = 95)
  table_overlap95 = rbind(t3,table_overlap95)
}


table_overlap <- rbind(table_overlap50,table_overlap75,table_overlap95)
write.csv(table_overlap,'output/PHAET/isotopos_overlap.csv')

ellipse75.overlap
