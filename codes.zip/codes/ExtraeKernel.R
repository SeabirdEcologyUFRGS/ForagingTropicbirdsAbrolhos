rm(list = ls())
library(RColorBrewer)
library(rgeos)
library(sftrack)
library(rnaturalearth) #mapas mundo
library(plotly)
library(ggmap)
library(mapdata)
library(maps)
library("rnaturalearthdata")
library(lubridate)
library(rgdal)
library(sf)
library(ggplot2)
library(dplyr)
library(MASS)
library(contoureR)
library(tibble)
library(tidyverse)
library(ggsn)
library(raster)
library(ggpolypath)
source("code/funciones/overlap_geral.R")
library(marmap) 
library(ncdf4) 
library(timeDate)
library(maptools) 
#Caargando mapa de isla y costa
world <- ne_countries(scale = "medium", returnclass = "sf",country = "Brazil")
class(world)
bra <- map_data("world2")
islaT <- read.csv("data/abrolhos.csv")
islaT <- islaT[,-1]

#Batimetria
FNlarge.gebco<-readGEBCO.bathy(file="data/GEBCO_26_Nov_2021_5baa65e33f07/gebco_2021_n-14.0_s-22.0_w-42.0_e-33.0.nc", 
                               resolution = 1)
bathy <- fortify.bathy(FNlarge.gebco)
# bathy<-FNlarge.gebco
# bathy <- as.matrix(bathy)
# class(bathy) <- "matrix"
# bat2 <- bathy %>%
#   as.data.frame() %>%
#   rownames_to_column(var = "lon") %>%
#   gather(lat, value, -1) %>%
#   mutate_all(funs(as.numeric))

#Poligono parque
a1 <- st_read("data/polygon_areas/parna_marinho_dos_abrolhos.kml")
a11 <- a1$geometry[[1]][2][[1]][[1]]
a12 <- a1$geometry[[1]][1][[1]][[1]]
a1 <- rbind(a11,a12)
a1 <- data.frame(lon = a1[,1], lat = a1[,2], group = c(rep(1,dim(a11)[1]),
                                                       rep(2,dim(a12)[1])))

#SEXOS
datos1 = read.csv("output/PHAET/HMM/HMM_sexo.csv")
datos1 <- datos1[which(datos1$state=='Forrageo'),]

lev <- 0.75
################################################################################
#Femea
load("output/PHAET/kernel/fem_akdeW_4.Rdata")
idd_fem <- UD2w_fem
raster1 <- as.sf(UD2w_fem,error=FALSE)
rm(UD2w_fem)

x = idd_fem@.Data[[11]]$x
y = idd_fem@.Data[[11]]$y
z = idd_fem@.Data[[9]]
xy <- expand.grid(x,y)

## pasando a raster
araster = rasterFromXYZ(data.frame(x=xy$Var1,y=xy$Var2,z=matrix(z,ncol=1)))
# Contour 95
a95 <- rasterToContour(araster, levels=c(lev))

coords.x1 <- NULL
coords.x2 <- NULL
for(i in 1:lengths(coordinates(a95))){
  coords.x1_1 = coordinates(a95)[[1]][[i]][,1]
  coords.x2_1 = coordinates(a95)[[1]][[i]][,2]
  coords.x1 <- c(coords.x1,coords.x1_1)
  coords.x2 <- c(coords.x2,coords.x2_1)
}
plot(coords.x1,coords.x2)

sp95 <- SpatialPoints(cbind(coords.x1,coords.x2), proj4string=CRS("+proj=utm +zone=25 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs")) 
sp95 <- spTransform(sp95, CRS("+proj=longlat +datum=WGS84"))
iid_fem <- coordinates(sp95)
iid_fem <- as.data.frame(iid_fem)
# iid95$z <- a95$z
iid_fem$z <- lev

################################################################################
#Macho
load("output/PHAET/kernel/ma_akdeW_4.Rdata")
idd_ma <- UD2w_ma

raster2 <- as.sf(UD2w_ma,error=FALSE)

# ggplot() + 
#   geom_sf(data = world, fill = 'gray', color = 'black')+
#   geom_sf(data = raster1, fill = "blue", color = "blue", alpha = 0.5) +
#   geom_sf(data = raster2, fill = 'red', color = 'red', alpha = 0.5) + 
#   coord_sf(xlim = c(-42,-35), ylim = c(-22,-15))
# 
# 
# 
# interC2 <- st_intersection(raster1,raster2) #%>% 
#   mutate(areaIn = as.vector(st_area(geometry))/10000000) %>% 
#   mutate(area_por = (areaIn/areakm)*100)
# tabla <- st_set_geometry(interC2,NULL) 
# tabla <- tabla[-1]
# 
# 
# st_intersection(raster1,raster2)
# 
# 
# rm(UD2w_ma)

x = idd_ma@.Data[[11]]$x
y = idd_ma@.Data[[11]]$y
z = idd_ma@.Data[[9]]
xy <- expand.grid(x,y)

araster = rasterFromXYZ(data.frame(x=xy$Var1,y=xy$Var2,z=matrix(z,ncol=1)))
# Contour 95
a95 <- rasterToContour(araster, levels=c(lev))

coords.x1 <- NULL
coords.x2 <- NULL
group <- NULL
for(i in 1:lengths(coordinates(a95))){
  coords.x1_1 = coordinates(a95)[[1]][[i]][,1]
  coords.x2_1 = coordinates(a95)[[1]][[i]][,2]
  group <- c(group, rep(i,length(coords.x2_1)))
  coords.x1 <- c(coords.x1,coords.x1_1)
  coords.x2 <- c(coords.x2,coords.x2_1)
}
plot(coords.x1,coords.x2)

sp95 <- SpatialPoints(cbind(coords.x1,coords.x2), proj4string=CRS("+proj=utm +zone=25 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs")) 
sp95 <- spTransform(sp95, CRS("+proj=longlat +datum=WGS84"))
iid_ma <- coordinates(sp95)
iid_ma <- as.data.frame(iid_ma)
iid_ma$z <- lev
iid_ma$group <- group

data1 <- iid_fem[which(iid_fem$z == as.character(lev)),]
data2 <- iid_ma[which(iid_ma$z == as.character(lev)),]

# Puntos de fem y mach
d1 <- datos1 %>% 
  dplyr::select('ID',"longitude","latitude","timestamp","sexo")
df <- d1[which(d1$sexo == "f"),]
dm <- d1[which(d1$sexo == "m"),]

#Plots
#Sexo
p_s <- ggplot(data = world) +
  geom_sf() +
  coord_sf(xlim = c(-42,-35), ylim = c(-22,-15))+
  geom_contour(data = bathy, aes(x=x, y=y, z=z), breaks=c(-1000), size=c(0.15),
               colour="grey23")+
  geom_text(aes(x = -40.1, y = -21.7), label = "-1000", color = "grey23", size = 1.5, 
            angle = 110, fontface = 'bold')+
  geom_text(aes(x = -38.55, y = -21.3), label = "-3000", color = "grey23", size = 1.5, 
            angle = 85, fontface = 'bold')+
  geom_text(aes(x = -40.5, y = -14.9), label = "Brazil", color = "black", size = 2.5, 
            fontface = 'bold')+
  geom_contour(data = bathy, aes(x=x, y=y, z=z), breaks=c(-3000), size=c(0.1),
               colour="grey23")+
  north(x.min = -42, x.max = -35,
        y.min = -22, y.max = -15,location = "topleft", symbol = 1)+
  ggsn::scalebar(x.min = -42, x.max = -35.5, border.size = 0.1,
                 y.min = -22, y.max = -15, dist = 50, dist_unit = "km",
                 transform = TRUE, model = "WGS84", st.size = 2)+
  geom_polygon(data = data1, aes(x = coords.x1, y = coords.x2),
               alpha = 0.6, show.legend = F, fill = 'coral2')+
    geom_polypath(data=data2,aes(x = coords.x1, y = coords.x2),
                alpha = 0.5, show.legend = F,fill = 'aquamarine4')+
  geom_point(data = df, aes(x = longitude, y = latitude),
             col = "coral2", size = 0.2, show.legend = T)+
  geom_point(data = dm, aes(x = longitude, y = latitude),
             col = "aquamarine4", size = 0.2, show.legend = T)+
  geom_path(data = a1, aes(x = lon, y=lat, group = group), color = "blue")+
  ylab("Latitude")+
  xlab("Longitude")+
  geom_polygon(data = islaT,aes(x = V1,y=V2, group = 1), colour = "black")+
  scale_color_manual(limits=c("Females", "Males","AMNP","Abrolhos Archipelago"),
                     values = c("coral2","aquamarine4","red","black")) +
  guides(colour = guide_legend(override.aes = list(pch = c(20, 20, 15, 20),
                                                   col = c("coral2",
                                                           "aquamarine4", "blue",
                                                           "black"), 
                                                   cex = c(2,2,2,2),
                                                   alpha = 0.7)))+
  theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        legend.key = element_rect(fill = "transparent", colour = "transparent"),
        axis.line = element_line(colour = "black"), 
        legend.background = element_rect(fill = "transparent", colour = NA),
        legend.box.background = element_rect(fill = "transparent", colour = NA),
        legend.position = c(0.82,0.92), axis.text = element_text(size = 6.2),
        axis.title = element_text(size = 8), 
        plot.title = element_text(size = 10),
        legend.text = element_text(size = 8),
        legend.key.size = unit(0.05, 'cm'))

ggsave(plot = p_s, width = 12,height = 12,units = "cm",
       filename = paste("figures/PHAET/kernel_sex_4_7522.tiff")) 
ggsave(plot = p_s, width = 12,height = 12,units = "cm",
       filename = paste("figures/PHAET/kernel_sex_4_7522.png"))
#OVERLAP
x <- "output/PHAET/kernel/fem_akdeW_4.Rdata"
y <- "output/PHAET/kernel/ma_akdeW_4.Rdata"
result1 <- overlap_geral(x,y)


################################################################################
#Estacion
################################################################################
#Seco
##################################### AKDE #####################################
d1 <- read.csv('output/PHAET/HMM/resultados_HMM_2.csv')
d1 <- d1[which(d1$states == 'Forrageo'),]
d1$datetime <- as.POSIXct(strptime(d1$datetime,format="%Y-%m-%d %H:%M"),
                          tz="GMT")
d1$mes <- month(d1$datetime)
d1$estacion <- NA
d1$estacion[which(d1$mes < 4 | d1$mes > 10)] = 1
d1$estacion[which(is.na(d1$estacion))] = 2
d1$estacion <- as.factor(d1$estacion)
levels(d1$estacion) <- c('ch','sec')

lev <- 0.95
load("output/PHAET/kernel/se_akdeW.Rdata")
akde_ma <- UD2w_se

x = akde_ma@.Data[[11]]$x
y = akde_ma@.Data[[11]]$y
z = akde_ma@.Data[[9]]
xy <- expand.grid(x,y)

# Contour 95
araster = rasterFromXYZ(data.frame(x=xy$Var1,y=xy$Var2,z=matrix(z,ncol=1)))
# Contour 95
a95 <- rasterToContour(araster, levels=c(lev))

coords.x1 <- NULL
coords.x2 <- NULL
for(i in 1:lengths(coordinates(a95))){
  coords.x1_1 = coordinates(a95)[[1]][[i]][,1]
  coords.x2_1 = coordinates(a95)[[1]][[i]][,2]
  coords.x1 <- c(coords.x1,coords.x1_1)
  coords.x2 <- c(coords.x2,coords.x2_1)
}
plot(coords.x1,coords.x2)
sp95 <- SpatialPoints(cbind(coords.x1,coords.x2), proj4string=CRS("+proj=utm +zone=25 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs"))
sp95 <- spTransform(sp95, CRS("+proj=longlat +datum=WGS84"))
akdew_ma <- coordinates(sp95)
akdew_ma <- as.data.frame(akdew_ma)
akdew_ma$z <- lev

#Lluvia
##################################### AKDE #####################################
load("output/PHAET/kernel/ch_akdeW.Rdata")
akde_fem <- UD2w_ch

x = akde_fem@.Data[[11]]$x
y = akde_fem@.Data[[11]]$y
z = akde_fem@.Data[[9]]
xy <- expand.grid(x,y)

# Contour 95
araster = rasterFromXYZ(data.frame(x=xy$Var1,y=xy$Var2,z=matrix(z,ncol=1)))
# Contour 95
a95 <- rasterToContour(araster, levels=c(lev))

coords.x1 <- NULL
coords.x2 <- NULL
for(i in 1:lengths(coordinates(a95))){
  coords.x1_1 = coordinates(a95)[[1]][[i]][,1]
  coords.x2_1 = coordinates(a95)[[1]][[i]][,2]
  coords.x1 <- c(coords.x1,coords.x1_1)
  coords.x2 <- c(coords.x2,coords.x2_1)
}
plot(coords.x1,coords.x2)
sp95 <- SpatialPoints(cbind(coords.x1,coords.x2), proj4string=CRS("+proj=utm +zone=25 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs"))
sp95 <- spTransform(sp95, CRS("+proj=longlat +datum=WGS84"))
akdew_fem <- coordinates(sp95)
akdew_fem <- as.data.frame(akdew_fem)
akdew_fem$z <- lev

#Puntos de ch y sec
d1 <- d1 %>% 
  dplyr::select('ID',"x","y","datetime","estacion")
ds <- d1[which(d1$estacion == "sec"),]
dc <- d1[which(d1$estacion == "ch"),]

data3 <- akdew_fem[which(akdew_fem$z == as.character(lev)),] #sec
data4 <- akdew_ma[which(akdew_ma$z == as.character(lev)),] #chu

p_s2 <- ggplot(data = world) +
  geom_sf() +
  coord_sf(xlim = c(-42,-35), ylim = c(-22,-15))+
  north(x.min = -42, x.max = -35,
        y.min = -22, y.max = -15,location = "topleft", symbol = 1)+
  ggsn::scalebar(x.min = -42, x.max = -35, border.size = 0.1,
                 y.min = -22, y.max = -15, dist = 50, dist_unit = "km",
                 transform = TRUE, model = "WGS84", st.size = 1.5)+
  geom_polygon(data = data4, aes(x = coords.x1, y = coords.x2),
               alpha = 0.5, show.legend = F, fill = "chocolate1")+
  geom_polygon(data=data3,aes(x = coords.x1, y = coords.x2),
               alpha = 0.5, show.legend = F, fill = "cyan4")+
  geom_point(data = ds, aes(x = x, y = y),
             col = "chocolate1", size = 0.4, show.legend = T)+
  geom_point(data = dc, aes(x = x, y = y),
             col = "cyan4", size = 0.2, show.legend = T)+
  ylab("Latitude")+
  xlab("Longitude")+
 # ggtitle(paste0("AKDE (95%)"))+
  geom_polygon(data = islaT,aes(x = V1,y=V2, group = 1), colour = "black")+
  scale_color_manual(limits=c("Dry", "Wet"),
                     values = c("chocolate1","cyan4")) +
  guides(colour = guide_legend(override.aes = list(pch = c(20, 20),
                                                   col = c("chocolate1","cyan4"), 
                                                   cex = c(4),
                                                   alpha = 0.3)))+
  theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), legend.position = c(0.85,0.9),
        axis.line = element_line(colour = "black"), 
       axis.title = element_text(size = 8), 
        plot.title = element_text(size = 10), 
       axis.text = element_text(size = 6),
       legend.text = element_text(size = 8),
       legend.key.size = unit(0.05, 'cm'))
ggsave(plot = p_s2, width = 10,height = 9,units = "cm",
       filename = paste("figures/PHAET/kernel_estacion.pdf")) 
ggsave(plot = p_s2, width = 10,height = 9,units = "cm",
       filename = paste("figures/PHAET/kernel_estacion.png"))


#OVERLAP
x <- "output/PHAET/kernel/ch_akdeW.Rdata"
y <- "output/PHAET/kernel/se_akdeW.Rdata"
result2 <- overlap_geral(x,y)


