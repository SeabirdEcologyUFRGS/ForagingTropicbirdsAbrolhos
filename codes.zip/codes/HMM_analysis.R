rm(list = ls())
library("data.table")
library("readr")
library('lubridate')
library("maps")
library("dplyr")
library("moveHMM")
library("factoextra")
library("mclust")
source("code/tesis/funciones/dis_robust.R")
library("HistDAWass")
library(rgdal)
source('code/funciones/get_k_ip.R')

################################################################################
# 1. Preparando bases para HMM
################################################################################
# Leyendo nueva base
files1 <- list.files("data/PHAET/regular_axytrek/",full.names = T)
files2 <- list.files("data/PHAET/regular_otros/",full.names = T)
files <- c(files1,files2)

baseR <- NULL

for(i in 1:length(files)){
  data <- read.csv(files[i], header = T)
  print(head(data))
  n <- nrow(data)
  if(i == 4){
    data <- data[-(171:nrow(data)),]
  }
  if(i == 5){
    data <- data[-(352:nrow(data)),]
  }
  
  if(i == 2){
    data <- data[1:178,]
  }
  if(i == 6){
    data <- data[1:346,]
  }
  # if(i == 16){
  #   data <- data[-c(1:76,496:nrow(data)),]
  # }
  if(i == 24){
    colnames(data) <- c("X","ID","datetime","lat","lon")
  }
  if(i == 28){
    data <- data[-(320:nrow(data)),]
  }
  
  data <-  data %>%
    dplyr::select("ID","datetime","lon","lat")
  
  baseR = rbind(baseR,data)
}

baseR$datetime <- as.POSIXct(strptime(baseR$datetime,
                                      format="%Y-%m-%d %H:%M:%S"),tz="GMT")


ano12 <- which(year(baseR$datetime) < 2013)
baseR <- baseR[-ano12,]

ggplot(data = baseR, aes(x=lon,y=lat, color = ID))+
  geom_path()

data.HMM <- prepData(baseR,coordNames = c('lon','lat'))
data.HMM$step[data.HMM$step == 0] <- 0.001

datakm <- data.HMM[-which(is.na(data.HMM$step) | is.na(data.HMM$angle)),]
set.seed(3)
in_par <- get_k_ip(datakm,4)

data.HMM$ID[which(data.HMM$step>20)]


id <- 'AVE_6_1'
dat2 <- data.HMM[which(data.HMM$ID == id),]
n <- nrow(dat2)
vel <- dat2$step/0.25
velmax <- max(vel, na.rm = T)
velmax
plot(dat2$x, dat2$y)
points(dat2$x[which(dat2$step==0)],dat2$y[which(dat2$step==0)], col = 'red')
points(dat2$x[which(vel>70)],dat2$y[which(vel>70)], col = 'blue')
points(dat2$x[1],dat2$y[1], col = 'green', pch = 4)
points(dat2$x[n],dat2$y[n], col = 'orange', pch = 5)


#modelo 4 estados
stepPar0 <-  c(6,   2,  0.2,   0.3,   
               4,   3,  0.1,    0.1)
anglePar0 <- c( 0,   0,    0,   0,  
                15,   1,   20,    40)

model_k1 <- fitHMM(data = data.HMM, nbStates = 4, stepPar0 = stepPar0,
                   anglePar0 = anglePar0)
plotPR(model_k1)
AIC(model_k1)
plot(model_k1)

states <- viterbi(model_k1)
data.HMM$states <- states

data.HMM$states <- as.factor(data.HMM$states)
levels(data.HMM$states) <- c("Trayecto","Forrageo","Descanso",'Deriva')