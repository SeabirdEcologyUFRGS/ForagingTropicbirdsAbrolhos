#ANALISIS POST-BUCEOS
rm(list=ls())
library(ggplot2)
library(dplyr)
library(lubridate)

base <- list.files('output/PHAET/mergulhos/mergulhos_viagem/', full.names = T)
islaT <- read.csv('data/abrolhos.csv')

total_dive <- NULL

for(i in 1:length(base)){
dat <- read.csv(base[i])
total_dive <- rbind(total_dive,dat)
}

#Separar por largos y cortos
#ave 14_3, 14_23_1, 24_1 incompletas no son cortas
base <- read.csv('output/PHAET/mergulhos/estats.csv')
in_men <- which(base$dur<13)
in_may <- which(base$dur>=13)
base$index <- NA
base$index[in_men] <- 'c'
base$index[in_may] <- 'l'
base$index[c(25,41,43)] <- NA
index <- base[,c(2,11)]

#distribucion de ambos
base2 <- merge(total_dive,index,'ID')
base2$dives <- base2$dives*-1
base2 <- base2[-which(is.na(base2$index)),]
base2$index <- as.factor(base2$index)

library(tidyr)
estat2 <- base2 %>% 
  dplyr::select(c(ID,index,dist.nid,time_acum,dives)) %>% 
  gather(variable, value, "dist.nid":"dives") %>% 
  mutate(variable = as.factor(variable)) %>% 
  group_by(variable, index) %>% 
  summarise(mean=mean(value), sd = sd(value), n=n(), max = max(value),
            num = mean(n()))

max_group <- base2 %>% 
  select(c(ID,index,dives)) %>% 
  group_by(index,ID) %>% 
  summarise(max_id = max(dives)) %>% 
  group_by(index) %>% 
  summarise(mean = mean(max_id), sd = sd(max_id))



  gather(variable, value, "dist.nid":"dives") %>% 
  mutate(variable = as.factor(variable)) %>% 
  group_by(variable, index) %>% 
  summarise(mean=mean(value), sd = sd(value), n=n(), max = max(value),
            num = mean(n()))



dist_mid1 <- base2 %>% 
  dplyr::select(c(ID,index,dist.nid,X)) %>% 
  group_by(ID,index,X) %>% 
  filter(X == 1) %>% 
  dplyr::select(c(index,dist.nid)) %>% 
  group_by(index) %>% 
  summarise(meand = mean(dist.nid)/1000, sd = sd(dist.nid)/1000)

  n2 <- base2 %>% 
  group_by(index,ID) %>% 
  summarise(n = n()) %>%
  group_by(index) %>% 
  summarise(dd = mean(n), sd = sd(n))

base2$index <- as.factor(base2$index)
levels(base2$index) <- c('Short trips', 'Long trips')
base2$index <- factor(base2$index, levels = c('Long trips', 'Short trips'))
buceos <- base2
g1 <- ggplot(buceos, aes(dives,fill=index,color=index))+
  geom_density(alpha=0.7, color = NA, show.legend = T)+
  scale_x_continuous(limits = c(0.3,1.8), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0,1.7), expand = c(0, 0)) +
  ylab('Density')+
  xlab('Depth of dives (m)')+
  theme_bw()+
  scale_fill_manual(values = c("blue", "darkgoldenrod2"))+
  theme(axis.title = element_text(size = 11), axis.text = element_text(size = 9),
        legend.position = c(.9,.9), 
        legend.text = element_text(size = 10 ),
        legend.title = element_blank(), legend.background = element_rect(fill = NA))
 # ggsave('figures/PHAET/mergulhos/l_c_hist_dives.png', g1, width = 15, 
 #       height = 9, units = 'cm')

 
 base <- list.files('output/PHAET/mergulhos/mergulhos_viagem/', full.names = T)
 total_dive <- NULL
  for(i in 1:length(base)){
   dat <- read.csv(base[i])
   total_dive <- rbind(total_dive,dat)
 }
 sex <- read.csv('output/PHAET/aves_sexo.csv')
 ID <- read.csv('output/PHAET/ave_num.csv')
 
 sexo <- merge(ID,sex[,2:3],'numero')
 sexo <- sexo[-which(sexo$sexo == ''),2:3]
 
 d1 <- merge(total_dive,sexo,'ID')
 d1$dives <- d1$dives*-1
 base2 <- d1 %>% 
   select(c(sexo,dives)) %>% 
   mutate( sexo = as.factor(sexo))
 levels(base2$sexo) <- c('Female','Male')
 g2 <- ggplot(base2, aes(dives,fill=sexo,color=sexo))+
   geom_density(alpha=0.7, color = NA)+
   scale_x_continuous(limits = c(0.3,1.8), expand = c(0, 0)) +
   scale_y_continuous(limits = c(0,1.7), expand = c(0, 0)) +
   ylab('Density')+
   xlab('')+
   theme_bw()+
   scale_fill_manual(values = c("coral2","aquamarine4"))+
   theme(axis.title = element_text(size = 11), axis.text = element_text(size = 8),
         legend.position = c(.89,.89), 
         legend.text = element_text(size = 10),
         legend.title = element_blank(),
         legend.background = element_rect(fill = NA),
         axis.title.x = element_blank())
 
 figure <- ggarrange(g2, NULL, g1,
                     labels = c("","",""), heights =  c(1,0.001, 1),
                     ncol = 1)
 figure
 ggsave('figures/PHAET/mergulhos/sex_density_dives.png', figure, width = 15, 
        height = 15, units = 'cm')
 ggsave('figures/PHAET/mergulhos/sex_density_dives.tiff', figure, width = 15, 
        height = 15, units = 'cm')
 
 
 
 total_dive$dives <- total_dive$dives*-1
 
 g2 <- ggplot(total_dive, aes(dives))+
   geom_histogram(alpha=0.7, show.legend = F, fill = 'gray', colour = 1)+
   scale_x_continuous(limits = c(0.3,1.8), expand = c(0, 0)) +
   scale_y_continuous(limits = c(0,45), expand = c(0, 0)) +
   ylab('Number of dives')+
   xlab('Depth of dives (m)')+
   theme_bw()+
   theme(axis.title = element_text(size = 12), axis.text = element_text(size = 10),
         legend.position = c(.9,.9), 
         legend.text = element_text(size = 7),
         legend.title = element_blank(), legend.background = element_rect(fill = NA))
 ggsave('figures/PHAET/mergulhos/hist_dives.png', g2, width = 15, 
        height = 9, units = 'cm')
 
#Tests
library(coin)
t1 <- wilcox_test(dives~index,data=base2)
#No tienen diferencias

#stats por viajes
num_viaje <- base2 %>% 
  select(ID,dives,index) %>% 
  group_by(ID,index) %>% 
  summarise(n = n()) %>% 
  group_by(index) %>% 
  summarise(mean(n))

med_viaje <- base2 %>% 
  select(dives,index) %>% 
  group_by(index) %>% 
  summarise(mean = mean(dives),
            sd = sd(dives))

#Profundidas en el espacio
ggplot(base2,aes(lon2,lat2, color = dives))+
  geom_point()+
  geom_point(aes(x = -38.7000 , y = -17.9633), colour = 'red')+ 
  theme_bw()

#Horas de mergulhos

total_dive$datetime <- as.POSIXct(total_dive$datetime, format = '%Y-%m-%d %H:%M:%S')
total_dive$hora <- hour(total_dive$datetime)-3
g2 <- ggplot(total_dive, aes(x = as.factor(hora)))+
  geom_histogram(alpha=0.7, show.legend = F, fill = 92,
                 colour = 92, stat = 'count')+
  # scale_x_continuous(expand = c(0.01, 0)) +
  scale_y_continuous(limits = c(0,60), expand = c(0,0)) +
  ylab('Number of dives')+
  xlab('Time (hour)')+
  theme_bw()+
  theme(axis.title = element_text(size = 10), axis.text = element_text(size = 8),
        legend.position = c(.9,.9), 
        legend.text = element_text(size = 7),
        legend.title = element_blank(), legend.background = element_rect(fill = NA))
g2

ggsave('figures/PHAET/mergulhos/hist_dives_time.png', g2, width = 15, 
       height = 9, units = 'cm')






################################################################################
#Diferencias entre sexo

sex <- read.csv('output/PHAET/aves_sexo.csv')
ID <- read.csv('output/PHAET/ave_num.csv')

sexo <- merge(ID,sex[,2:3],'numero')
sexo <- sexo[-which(sexo$sexo == ''),2:3]

d1 <- merge(total_dive,sexo,'ID')
d1$dives <- d1$dives*-1
estat_sex <- d1 %>% 
  dplyr::select(c(sexo,dist.nid,time_acum,dives)) %>% 
  gather(variable, value, "dist.nid":"dives") %>% 
  mutate(variable = as.factor(variable), sexo = as.factor(sexo)) %>% 
  group_by(variable,sexo) %>% 
  summarise(mean=mean(value), sd = sd(value), n=n(), max = max(value))

index <- d1 %>% 
  dplyr::select(c(ID,sexo,X)) %>% 
  group_by(ID,sexo) %>% 
   summarise(min= min(X))
  # summarise(meand = mean(min)/1000, sd = sd(min)/1000)


dist_mid2 <- d1 %>% 
  dplyr::select(c(ID,sexo,dist.nid,X)) %>% 
  group_by(ID,sexo,X) %>% 
  filter(X == 1) %>% 
  dplyr::select(c(sexo,dist.nid)) %>% 
  group_by(sexo) %>% 
  summarise(meand = mean(dist.nid)/1000, sd = sd(dist.nid)/1000)

max_sexo <- d1 %>% 
  select(c(ID,sexo,dives)) %>% 
  group_by(sexo,ID) %>% 
  summarise(max_id = max(dives)) %>% 
  group_by(sexo) %>% 
  summarise(mean = mean(max_id), sd = sd(max_id))




max_dives <- d1 %>% 
  dplyr::select(c(ID,sexo,dist.nid,X)) %>% 
  group_by(ID,sexo,X) %>% 
  filter(X == 1) %>% 
  dplyr::select(c(sexo,dist.nid)) %>% 
  group_by(sexo) %>% 
  summarise(meand = mean(dist.nid)/1000, sd = sd(dist.nid)/1000)






n <- d1 %>% 
  group_by(sexo,ID) %>% 
  summarise(n = n()) %>%
  group_by(sexo) %>% 
  summarise(dd = mean(n), sd = sd(n))


ggplot(data=d1,aes(x = lon2,y=lat2,color=sexo))+
  geom_point()+
  geom_point(data = islaT, aes(x = V1,y = V2), color = 'black')+
  theme_bw()

ggplot(data=d1,aes(dives,fill=sexo))+
  geom_histogram()+
  # geom_point(data = islaT, aes(x = V1,y = V2), color = 'black')+
  theme_bw()

