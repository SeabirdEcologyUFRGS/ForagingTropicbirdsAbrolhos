regularizar <- function(name_d, time){
  data <- fread(name_d, header = T)
  n1 <- dim(data)[1]
  #print(i)
  print(dim(data))
  
  data$datetime <-as.POSIXct(strptime(data$datetime,format="%Y-%m-%d %H:%M"),
                             tz="GMT")
  stepdur <-diff(x = data$datetime, units="mins")
  
   if(max(stepdur) > 3000){
     print(paste("ALERTAAA",data$ID[1]))
  }
  
  # Iniciando regularizacion
  data$stepdur<- c(NA,stepdur)
  date.start <- data$datetime[1]
  date.end <- data$datetime[n1]
  
  #Duracion del viaje
  dur.trip<-(date.end-date.start)
  
  #Regularizacion lineal
  z <- as.difftime(time, units = "mins")
  xout <- seq(from=data$datetime[1],to=data$datetime[n1],by=z)
  aprox.lon <- approx(data$datetime,data$lon,xout=xout)
  aprox.lat <- approx(data$datetime,data$lat,xout=xout)
  aprox.lon <- as.vector(unlist(aprox.lon$y))
  aprox.lat <- as.vector(unlist(aprox.lat$y))
  
#Juntando datos regularizados
  data.reg<-data.frame(ID = data$ID[1], datetime = xout, lon = aprox.lon, 
                                lat = aprox.lat)
 # names(data.reg)<-c("ID", "datetime","lon","lat")
  row.names(data.reg) <- seq(1,nrow(data.reg))
  
  return(data.reg)
  
}

