distance_ortho_robuste<-function(lat1m,lat2m,lon1m,lon2m){
  R <- 6376323
  dist.m<-R*2*asin(
    ((sin((lat1m*pi/180-lat2m*pi/180)/2))^2+
       cos(lat1m*pi/180)*cos(lat2m*pi/180)*(sin((lon1m*pi/180-lon2m*pi/180)/2))^2)^.5)
  return(dist.m)
  end
}