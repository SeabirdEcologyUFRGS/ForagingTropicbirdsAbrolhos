GPS_TDR <- function(name_d){
  allData = fread(name_d,
                  showProgress = FALSE)
  allData <- allData[,1:17]
  names(allData) = c('TagID','date','hour','X','Y','Z','Activity','Pressure',
                     'Temp','lat','lon','height-msl','ground-speed','satellites',
                     'hdop','signal-strength','sensor_raw')
  
  allData <- allData %>% 
    dplyr::select("TagID","date","hour","Pressure","lat","lon")
  
  index <- sort(unique(c(which(!is.na(allData$lat)),
                         which(!is.na(allData$Pressure)))))
  data <- allData[index,]
  ndim = dim(data)
  ind1 = which(!is.na(data$lat))
  data <- data[ind1[1]:ind1[length(ind1)],]
  
  # eliminandola data total
  rm(allData)
  
  if (ind1[1] > 1){print(paste(f,"GPS no empieza en primera obs"))}
  
  n1 <- dim(data)[1]
  data$datetime <- as.POSIXct(strptime(paste(as.character(data$date),
                                             as.character(data$hour),sep=" "),
                                       format="%d/%m/%Y %H:%M:%OS"),tz="GMT")
  stepdur <- diff(x = data$datetime, units="secs")
  
  lat2 <- NULL
  t2 <- which(!is.na(data$lat))
  diff <- diff(t2)
  
  for(p in 1:(length(t2)-1)){
    t1 <- seq(data$lat[t2[p]],data$lat[t2[p+1]],
              length.out = (diff[p]+1)) 
    if(p > 1){
      t1 <- t1[-1]
    }
    lat2 <- c(lat2,t1)
  }
  
  lon2 <- NULL
  for(p in 1:(length(t2)-1)){
    t1 <- seq(data$lon[t2[p]],data$lon[t2[p+1]],
              length.out = diff[p]+1) 
    if(p > 1){
      t1 <- t1[-1]
    }
    lon2 <- c(lon2,t1)
  }
  
  data$lon2 = rep(NA, n1)
  data$lat2 = rep(NA, n1)
  
  data$lon2 = lon2
  data$lat2 = lat2
  return(data)
}
