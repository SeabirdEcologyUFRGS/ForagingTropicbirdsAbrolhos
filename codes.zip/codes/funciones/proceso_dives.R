cortes_dives <- function(data,dist_col,f,num){
  
  source("code/funciones/dis_robust.R")
  complet_vec <- function(x = x){
    for(k in 1:length(x)){
      if(is.na(x[k]) == T){
        x[k] <- x[k-1]
      } } 
    return(x)
  }
  
  
  data_Trip = NULL
  
  n <- nrow(data)
  data$id2 <-c(1:n) 
  data$lat3 <- complet_vec(data$lat)
  data$lon3 <- complet_vec(data$lon)
  #Tiempos (s) entre primer punto y cada punto
  tps.cum<-difftime(data$datetime[2:n], data$datetime[1], units="secs")
  tps.cum <- as.numeric(tps.cum)
  
  #Tiempo entre pasos
  tps.unit <- difftime(data$datetime[2:n],data$datetime[1:n-1],units="secs")
  tps.unit[tps.unit==0]=0.5
  tps.unit <- as.numeric(tps.unit)
  
  #Distancia entre pasos
  dist.unit <- distance_ortho_robuste(data$lat2[2:n],data$lat2[1:n-1],
                                      data$lon2[2:n],data$lon2[1:n-1])
  
  #Distancia al nido, tomando centro de archipielago
  dist.nid <- distance_ortho_robuste(-17.9633,data$lat2[2:n],-38.7000,
                                     data$lon2[2:n])
  
  #Velocidad
  speed.ms<-dist.unit/as.numeric(tps.unit)
  speed.kmh<-round(speed.ms/1000*3600)
  
  #Grupos
  #source("code/group.R")
  source("code/funciones/grpt.R")
  
  trip <- grpt(dist.nid, dist.nid>dist_col)
  vol <- grpt(speed.kmh, speed.kmh>10)
  
  #Juntar datos
  data2<-cbind(data[-1,],trip,vol,dist.nid)
  data2$id<-data2$id-1
  
  #Reperage des d?parts et arriv?es des trips
  maxT <- tapply(data2$id, as.factor(trip), max, na.rm=T)  
  minT <- tapply(data2$id, as.factor(trip), min, na.rm=T)
  
  #Reperage des vitesses >7kmh
  maxV <-tapply(data2$id, as.factor(vol), max, na.rm=T)  
  minV <-tapply(data2$id, as.factor(vol), min, na.rm=T) 
  
  xx <- minT==maxT
  xx <- xx==FALSE
  
  minT<-minT[xx]
  maxT<-maxT[xx]
  
  print(minT)
  

summary_tdr <- NULL

  for(j in 1:length((minT))){
    a<-rep(minT[j],times=length(minV))-minV
    if(any(a>0)){deb.trip=minV[which(a==min(a[a>=0]))]}else{deb.trip=minT[j]}
    
    if(j>1){
      if(deb.trip<maxT[j-1]){deb.trip=(maxT[j-1]+1)}else{deb.trip=deb.trip}}
    
    c<-rep(maxT[j],times=length(maxV))-maxV
    if(any(c<0)){fin.trip=maxV[which(c==max(c[c<=0]))]}else{fin.trip=maxT[j]}
    
    if(j<length(minT)){
      if(fin.trip>minT[j+1]){fin.trip=(minT[j+1]-1)}else{fin.trip=fin.trip}}
    
    trip.selec<-data2[deb.trip:fin.trip,]
    trip.selec$ave <- paste0("AVE_",num[f])
    trip.selec$ID <- paste0(trip.selec$ave,"_",j)
    dur = trip.selec$datetime[nrow(trip.selec)]-trip.selec$datetime[1]
    
################################# PRESION ######################################
 presion = trip.selec$Pressure
 presion <- presion[!is.na(presion)]
 presion <- presion*-0.00102
 presion[presion>0] = 0
 #Corrigiendo presion a nivel del mar y ceros
 # correction = zoo::rollmedian(presion, 5, na.pad = TRUE)
 # pressure_corr <- presion - correction
 # pressureN <- NA
 # pressureN <- pressure_corr*-1
 # pressureN[pressureN>0] = 0
 # pressureN[which(is.na(pressureN))] = 0
 # pressureN <- pressureN*0.01

 nn <- grpt(presion,presion < -0.3)

 
 if(length(which(!is.na(nn)))>0){
 base_dives <- NULL
 base_dives <- trip.selec
 base_dives$dives <- presion
 n2 <- nrow(base_dives)
 tps.div<-difftime(base_dives$datetime[2:n2], base_dives$datetime[1], units="secs")
 tps.div <- as.numeric(tps.div)
 base_dives$time_acum <- c(NA,tps.div)
 base_dives$grupo_g <- as.factor(nn)
 base_dives <- base_dives[-which(is.na(nn)),]

 
 dives <- NULL
 
 for(i in levels(base_dives$grupo_g)){
   
   mm <- which(base_dives$grupo_g == i)
   a <- which.min(base_dives$dives[mm])
   dives <- c(dives,mm[a])
}
 
 base_d <- base_dives[dives,c(18,7,8,9,15,20,19,21)]
 # s <- base_d$time_acum
 # 
 # for(a in 1:length(s)){
 #   p1 <- s[a]-10
 #   p2 <- s[a]+10
 #   print(a) 
 #   plot(x = p1:p2,y = pressureN[p1:p2],ylim = c(-2,0), main = trip.selec$ID[1] )
 # 
 # }
 # inP <- which(pressureN > -0.3)
 # pressureN[inP] = 0
 nn <- grpt(pressureN,pressureN < -0.3)
 #write.csv(base_d,paste0('output/PHAET/mergulhos_viagem/',base_d$ID[1],'.csv'))
  #Calculando estadisticas de TDR
  ndiv1 <- nrow(base_d)
  mean1 <- mean(base_d$dives)
  median1 <-  median(base_d$dives)
  max1 <-  min(base_d$dives)
  stats_tdr <- data.frame(ID = unique(base_d$ID), n = ndiv1,
                          mean = mean1, median = median1,
                          max = max1, dist_1 = base_d$dist.nid[1], 
                          dist_max = max(base_d$dist.nid), 
                          tim_1 = base_d$time_acum[1], dur = dur)
  summary_tdr <- rbind(summary_tdr,stats_tdr)
  }
 }
  
  return(summary_tdr)
  
}   
