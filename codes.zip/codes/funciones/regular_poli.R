regularizar_poli <- function(name_d, time){
  data <- fread(name_d, header = T)
  n1 <- dim(data)[1]
  #print(i)
  print(dim(data))
  
  data$datetime <-as.POSIXct(strptime(data$datetime,format="%Y-%m-%d %H:%M"),
                             tz="GMT")
  stepdur <-diff(x = data$datetime, units="mins")
  
  # Iniciando regularizacion
  lo1 <- as.vector(data$lon[which(!is.na(data$lon))])
  la1 <- as.vector(data$lat[which(!is.na(data$lat))])
  n2 <- length(lo1)
  z<-as.difftime(time, units = "mins")
  xout<-seq(from=data$datetime[1],to=data$datetime[n1],by=z)
  
  n3 <- length(xout)
  
  base2 <- pchip(seq(1,n2,1),lo1,
                 seq(1,n2,length.out = n3))
  base3 <- pchip(seq(1,n2,1),la1,
                 seq(1,n2,length.out = n3))

  aprox.lon<-as.vector(base2)
  aprox.lat<-as.vector(base3)
  

  
  ################################## Diving ######################################
  # #Columnas de divings
  # ind <- c("d5", "d10", "d20", "d30", "d40", "d50", "d60", "d80", "d100")
  # incol <- NULL
  # for(r in 1:length(ind)){
  #   inc <- which(colnames(data) == ind[r])
  #   incol <- c(incol,inc)
  # }
  # 
  # #Sumando divings entre cada paso
  # sum_div <- rep(0,length(incol)) # Primera fila será 0
  # 
  # for(l in 1:(length(xout)-1)){
  #   datei <- min(which(data$datetime == xout[l]))
  #   datef <- max(which(data$datetime == xout[l+1]))
  #   dat2 <- data[datei:datef,]
  #   dat2 <- as.data.frame(dat2)
  #   dives = NULL
  #   for(d in 1:length(incol)){
  #     dat3 <- length(which(!is.na((dat2[,incol[d]]))))
  #     dives <- c(dives,dat3)
  #   }
  #   sum_div <- rbind(sum_div,dives)
  # }
  # sum_div <- as.data.frame(sum_div)
  
  #Juntando datos regularizados
  # data.reg<-as.data.frame(cbind(data$ave[1], data$ID[1], xout, aprox.lon, 
  #                               aprox.lat, sum_div))
  # names(data.reg)<-c("ave","ID", "datetime","lon","lat",ind)
  # row.names(data.reg) <- seq(1,nrow(data.reg))
  
  data.reg<-data.frame(data$ave[1], data$ID[1], xout, aprox.lon, 
                                aprox.lat)
  names(data.reg)<-c("ave","ID", "datetime","lon","lat")
  row.names(data.reg) <- seq(1,nrow(data.reg))
  
  return(data.reg)
  
}
