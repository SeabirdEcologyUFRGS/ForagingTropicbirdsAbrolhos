
#####################################################################################
#Fonction groupant des points de la trajectoire en fonction d'une condition (grpt)
#Retourne un vecteur numeric (longueur de x) avec les appartenances aux groupes
#####################################################################################
grpt <- function(x, condition) {    
		a1 <- condition
		a2 <- a1
		a3 <- a1
		# a2 =a1 decale d'une ligne 
		a2[2:length(a1)] <-  a1[1:(length(a1)-1)]  
		a2[1] <- FALSE
		# d�tection des entr�es et des sorties des s�quences
		a3 <- as.logical(ifelse(a1 != a2, "T","F"))
		grp <- rep("NA", length(a1))
		indice <- 1
		for (j in 1:length(a1))
		    {
			    if (a1[j]==TRUE & a3[j]==TRUE)   # changement
			     {
				     grp[j] <- paste(indice)  # num�rotation des s�quences
				     indice <- indice + 1
			     }
		      if (a1[j]==TRUE & a3[j]==FALSE)  # cas o� la s�quence est la m�me
		       {
			       grp[j] <- grp[j-1]
		       }
		        
		    }
		rm(a1, a2, a3) 
		grp <- as.numeric(grp)
    return(grp)
  }
