cortes_isla <- function(data,dist_col,f,especie,num){
  source("code/tesis/funciones/dis_robust.R")
  complet_vec <- function(x = x){
    for(k in 1:length(x)){
      if(is.na(x[k]) == T){
        x[k] <- x[k-1]
      } } 
    return(x)
  }
  
  
  data_Trip = NULL

  n <- nrow(data)
  data$id2 <-c(1:n) 
  data$lat2 <- complet_vec(data$lat)
  data$lon2 <- complet_vec(data$lon)
  #Tiempos (s) entre primer punto y cada punto
  tps.cum<-difftime(data$datetime[2:n], data$datetime[1], units="secs")
  tps.cum <- as.numeric(tps.cum)
  
  #Tiempo entre pasos
  tps.unit <- difftime(data$datetime[2:n],data$datetime[1:n-1],units="secs")
  tps.unit[tps.unit==0]=0.5
  tps.unit <- as.numeric(tps.unit)
  
  #Distancia entre pasos
  dist.unit <- distance_ortho_robuste(data$lat2[2:n],data$lat2[1:n-1],
                                      data$lon2[2:n],data$lon2[1:n-1])
  
  #Distancia al nido, tomando centro de archipielago
  dist.nid <- distance_ortho_robuste(-17.9633,data$lat2[2:n],-38.7000,
                                     data$lon2[2:n])
  
  #Velocidad
  speed.ms<-dist.unit/as.numeric(tps.unit)
  speed.kmh<-round(speed.ms/1000*3600)
  
  #Grupos
  #source("code/group.R")
  source("code/tesis/funciones/grpt.R")
  
  trip <- grpt(dist.nid, dist.nid>dist_col)
  vol <- grpt(speed.kmh, speed.kmh>10)
  
  #Juntar datos
  data2<-cbind(data[-1,],trip,vol)
  data2$id<-data2$id-1
  
  #Reperage des d?parts et arriv?es des trips
  maxT <- tapply(data2$id, as.factor(trip), max, na.rm=T)  
  minT <- tapply(data2$id, as.factor(trip), min, na.rm=T)
  
  #Reperage des vitesses >7kmh
  maxV <-tapply(data2$id, as.factor(vol), max, na.rm=T)  
  minV <-tapply(data2$id, as.factor(vol), min, na.rm=T) 
  
  xx <- minT==maxT
  xx <- xx==FALSE
  
  minT<-minT[xx]
  maxT<-maxT[xx]
  
  print(minT)
  
  new_base = NULL

  plot(data$lon2,data$lat2,xlim=c(-39.5,-36.3),
       ylim = c(min(data$lat2)-0.5,max(data$lat2)+0.5), type = "l",
       main = paste(data$TagID[1],"ave_",f))
  lines(islaT[,1],islaT[,2], col = "red",lwd = 2)
  lines(costa$lon,costa$lat, col = "brown")
  points(data$lon[1],data$lat[1], pch = 15, col = "#00B8E5")
  
  summary_tdr <- NULL
  for(j in 1:length((minT))){
    a<-rep(minT[j],times=length(minV))-minV
    if(any(a>0)){deb.trip=minV[which(a==min(a[a>=0]))]}else{deb.trip=minT[j]}
    
    if(j>1){
      if(deb.trip<maxT[j-1]){deb.trip=(maxT[j-1]+1)}else{deb.trip=deb.trip}}
    
    c<-rep(maxT[j],times=length(maxV))-maxV
    if(any(c<0)){fin.trip=maxV[which(c==max(c[c<=0]))]}else{fin.trip=maxT[j]}
    
    if(j<length(minT)){
      if(fin.trip>minT[j+1]){fin.trip=(minT[j+1]-1)}else{fin.trip=fin.trip}}
    
    trip.selec<-data2[deb.trip:fin.trip,]
    points(trip.selec$lon,trip.selec$lat,col = j)
    trip.selec$ave <- paste0("AVE_",num[f])
    trip.selec$ID <- paste0(trip.selec$ave,"_",j)

################################# PRESION ######################################
    presion = trip.selec$Pressure
    presion <- presion[!is.na(presion)]
    
    #Corrigiendo presion a nivel del mar y ceros
    correction = zoo::rollmedian(presion, 5, na.pad = TRUE)
    pressure_corr <- presion - correction
    pressureN <- NA
    pressureN <- pressure_corr*-1
    pressureN[pressureN>0] = 0
    pressureN[which(is.na(trip.selec$trip))] = 0
    presion_t <- data.frame(tiempo = 1:length(pressureN), presion = pressureN)
    presion_t$presion <- presion_t$presion*0.01
    div <- ggplot(presion_t)+
      geom_point(aes(x = tiempo, y = presion))+
      xlab("Time (sec)")+
      ylab("Depth (m)")+
      ylim(-3,0)+
      labs(title = trip.selec$ID[1])+
      theme_bw()
    ggsave(paste0("figure/",especie,"/mergulhos_2021/diving/viajes/",trip.selec$ID[1],
                  ".png"), div, width = 7,height = 4)
    
    # Threshold
    threshold = c(-5,-10,-20,-30,-40,-50,-60,-80,-100)
    ## acumulando lugares de mergulhos
    divings = matrix(NA,ncol=length(threshold),nrow=dim(trip.selec)[1])
    summary_diving <- NULL

    presion2 <- pressureN
    for(r in 1:length(threshold)){
      inP <- which(presion2 > threshold[r])
      presion2[inP] = 0
      div_1 <- rep(NA,length(presion2))
      indx1 <- which(ggpmisc:::find_peaks(-presion2,ignore_threshold = 0))
      div_1[indx1] <- presion2[indx1]*(-1)*0.01
      divings[,r] = div_1
    }
   colnames(divings) <- c("d5","d10","d20","d30","d40","d50","d60","d80","d100")
   new_base <- cbind(trip.selec,divings)
   
   png(paste0("figure/",especie,"/cortes_axy_2021/",new_base$ID[1],".png"),
        width = 11, height = 7, units = "cm",res = 200)
   par(mar = c(2,2,1,1))
   plot(na.omit(new_base$lon),na.omit(new_base$lat),xlim=c(-39.5,-36.3), type = "l",
        main = new_base$ID[1], cex.axis = 0.7, ylab = "lat", xlab = "lon")
   lines(islaT[,1],islaT[,2], col = "red",lwd = 2)
   lines(costa$lon,costa$lat, col = "brown")
   points(data$lon[1],data$lat[1], pch = 15, col = "#00B8E5")
   dev.off()
   #Guardando cada viaje (j)
   write.csv(x = new_base, file = paste0("data/",especie,"/analisis_2021/cortes_axytrek/",
                                         new_base$ID[1],".csv"), na = "")
   
   #Calculando estadisticas de TDR
   ndiv1 <- apply(divings, MARGIN = 2, function(x) sum(!is.na(x)))
   mean1 <- apply(divings,2,mean,na.rm = T)
   median1 <- apply(divings,2,median,na.rm = T)
   sd1 <- apply(divings,2,sd,na.rm = T)
   min1 <- apply(divings,2,min,na.rm = T)
   max1 <- apply(divings,2,max,na.rm = T)
   stats_tdr <- data.frame(ID = new_base$ID[1:length(threshold)], thre = threshold, n = ndiv1, 
                           mean = mean1, median = median1, sd = sd1, 
                           max = max1, min = min1)
   summary_tdr <- rbind(summary_tdr,stats_tdr)
   
    }
    
  return(summary_tdr)
    
}   
    
    
